package cs.dit.board;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BListService implements BoardService {

	private Object numOfRecords;

	@Override
	public void executte(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		BoardDao dao = new BoardDao();
		@SuppressWarnings("unused")
		int numberOfRecords = 10;
		int count = dao.recordCount();
		
		String page_ = request.getParameter("p");
		int p = 1;
		
		if(page_ !=null && !page_.equals(""))
			p = Integer.parseInt(page_);
		
	
		ArrayList<BoardDto> dtos = dao.list(p, numOfRecords);
		
		int startNum = p-((p-1)% 5);
		int numOfPages = 5;
		int lastNum = (int)Math.ceil(count/10.0);
		
		//BoardDao dao = new BoardDao();
		//ArrayList<BoardDto> dtos = dao.list();

		//5. 이 페이지의 저장소인 pageContext에 DB에서 검색해온 dtos 값을 저장하시오.
		request.setAttribute("dtos", dtos);
		request.setAttribute("p", p);
		request.setAttribute("startNum", startNum);
		request.setAttribute("lastNum", lastNum);
		request.setAttribute("numOfPages", numOfPages);
	}

}

